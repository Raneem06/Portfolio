//Navbar Scroll
window.addEventListener("scroll", function () {
  let navbar = document.querySelector(".navbar-default");
  if (window.scrollY > 50) {
    navbar.classList.add("scrolled");
  } else {
    navbar.classList.remove("scrolled");
  }
});

// Slider
document.addEventListener('DOMContentLoaded', () => {
  const slider = document.querySelector('.slider');
  if (!slider) return;

  const track = slider.querySelector('#slides');
  const slides = slider.querySelectorAll('.slide');
  const dotsWrap = slider.querySelector('.dots');
  const interval = +slider.dataset.interval || 5000;

  const dots = [...slides].map((_, i) => {
    const d = document.createElement('span');
    d.className = 'dot' + (i === 0 ? ' active' : '');
    d.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(d);
    return d;
  });

  let index = 0, timer;

  function update() {
    track.style.transform = `translateX(-${index * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === index));
  }
  function next() {
    index = (index + 1) % slides.length;
    update();
  }
  function goTo(i) {
    index = i;
    update();
    restart();
  }
  function start() { timer = setInterval(next, interval); }
  function stop() { clearInterval(timer); }
  function restart() { stop(); start(); }

  slider.addEventListener('mouseenter', stop);
  slider.addEventListener('mouseleave', start);

  update();
  start();
});


//Testimonial
// let index1 = 0;
// const wrapper = document.querySelector(".testimonial-wrapper");
// const slides1 = document.querySelectorAll(".testimonial-slide");
// const dots1 = document.querySelectorAll(".dot");
// const visibleSlides = window.innerWidth <= 768 ? 1 : 2; // responsive
// const totalPages = Math.ceil(slide.length / visibleSlides);

// function showSlide(n) {
//   index = n;
//   wrapper.style.transform = `translateX(-${index * 100}%)`;
//   dots.forEach(dot => dot.classList.remove("active"));
//   dots[index].classList.add("active");
// }

// function nextSlide() {
//   index = (index + 1) % totalPages;
//   showSlide(index);
// }

// dots.forEach((dot, i) => {
//   dot.addEventListener("click", () => showSlide(i));
// });

// Auto slide
// setInterval(nextSlide, 4000);


document.addEventListener('DOMContentLoaded', () => {
  const testimonialSlider = (() => {
    let currentIndex = 0;
    const wrapper = document.querySelector(".testimonial-wrapper");
    const slides = document.querySelectorAll(".testimonial-slide");
    const dots = document.querySelectorAll(".testimonial-dot");
    const visibleCount = window.innerWidth <= 768 ? 1 : 2;
    const totalPages = Math.ceil(slides.length / visibleCount);
    let timer;

    if (!wrapper || slides.length === 0) return;

    function updateSlider(index) {
      wrapper.style.transform = `translateX(-${index * 100}%)`;
      dots.forEach(dot => dot.classList.remove("active"));
      if (dots[index]) dots[index].classList.add("active");
    }

    function goTo(index) {
      currentIndex = index;
      updateSlider(currentIndex);
      restart();
    }

    function next() {
      currentIndex = (currentIndex + 1) % totalPages;
      updateSlider(currentIndex);
    }

    function start() {
      timer = setInterval(next, 4000);
    }

    function stop() {
      clearInterval(timer);
    }

    function restart() {
      stop();
      start();
    }

    // Dot click events
    dots.forEach((dot, i) => {
      dot.addEventListener("click", () => goTo(i));
    });

    // Hover pause (optional)
    wrapper.addEventListener("mouseenter", stop);
    wrapper.addEventListener("mouseleave", start);

    // Start slider
    updateSlider(currentIndex);
    start();
  })();
});

//Contact
const form = document.getElementById('contactForm');
const confirmation = document.getElementById('confirmation');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  confirmation.style.display = 'block';
  setTimeout(() => {
    confirmation.style.display = 'none';
  }, 5000);
  form.reset();
});
